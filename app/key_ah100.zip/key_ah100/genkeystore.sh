openssl pkcs8 -inform DER -nocrypt -in platform.pk8 -out platform.pem
openssl pkcs12 -export -in  platform.x509.pem -out platform.p12 -inkey  platform.pem -password pass:123456 -name newplatform
keytool -importkeystore -deststorepass 123456 -destkeystore ./newplatform.jks -srckeystore ./platform.p12 -srcstoretype PKCS12 -srcstorepass 123456
rm platform.pem platform.p12

